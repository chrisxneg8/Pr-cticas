<?php
function esPalindromo($cadena) {
    // Normalizar la cadena: convertir a minúsculas y eliminar caracteres no alfanuméricos
    $cadenaLimpia = strtolower(preg_replace("/[^A-Za-z0-9]/", '', $cadena));
    
    // Invertir la cadena normalizada
    $cadenaInvertida = strrev($cadenaLimpia);
    
    // Comparar la cadena original con la invertida
    return $cadenaLimpia === $cadenaInvertida;
}

// Ejemplo de uso
$cadena = "Christian Negreira";
if (esPalindromo($cadena)) {
    echo "La cadena \"$cadena\" es un palíndromo.";
} else {
    echo "La cadena \"$cadena\" no es un palíndromo.";
}
?>
