<?php
function resolverEcuacionCuadratica($a, $b, $c) {
    // Calcula el discriminante
    $discriminante = $b * $b - 4 * $a * $c;

    // Verifica si el discriminante es negativo, cero o positivo
    if ($discriminante < 0) {
        return "No hay soluciones reales.";
    } elseif ($discriminante == 0) {
        $x = -$b / (2 * $a);
        return "Hay una solución: x = $x";
    } else {
        $x1 = (-$b + sqrt($discriminante)) / (2 * $a);
        $x2 = (-$b - sqrt($discriminante)) / (2 * $a);
        return "Hay dos soluciones: x1 = $x1 y x2 = $x2";
    }
}

// Ejemplo de uso
$a = 1;
$b = -3;
$c = 2;
$resultado = resolverEcuacionCuadratica($a, $b, $c);
echo $resultado;
?>
