<?php
function filtrarArray($array, $limiteSuperior) {
    $nuevoArray = array();
    foreach ($array as $elemento) {
        if ($elemento < $limiteSuperior) {
            $nuevoArray[] = $elemento;
        }
    }
    return $nuevoArray;
}

$arrayOriginal = array(1, 2, 3);
$limiteSuperior = 3;
$arrayFiltrado = filtrarArray($arrayOriginal, $limiteSuperior);

print_r($arrayFiltrado);
?>
